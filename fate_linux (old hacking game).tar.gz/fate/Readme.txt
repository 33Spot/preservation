
==============
=  F A  T E  =
=    v0.2    =
==============


Welcome to Fate!
Produced by m101

For more information on Fate, visit fate.area-6.net 
or contact me on irc.area-6.net:6667 #area6

===============================================================================
                                   CONTENTS
===============================================================================

- Playing the Game

- Troubleshooting

===============================================================================
                                PLAYING THE GAME
===============================================================================

The Game is based to simulate a real life hack, you have to gain access to the
system, exploit it for root and then contact IRC to continue the mission.

If you are having problems passing a mission try reading the story line again,
you may have forgotten to clear the logs before contacting IRC again, or
something similar.

More help can be found on irc.area-6.net #area6

===============================================================================
                                TROUBLESHOOTING
===============================================================================

No troubleshooting is available at the moment sorry....







Version 0.25
=========

Level skip bug fixed
New mission server 'Morbid'


Version 0.2
=========

Three game missions added and more commands added

	-Mission Servers-
	Area6
	Trinity
	Zeon

Added intro skip menu


Version 0.1
=========

Basic game engine created

