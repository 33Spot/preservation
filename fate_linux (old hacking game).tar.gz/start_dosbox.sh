#LD_LIBRARY_PATH=LIBS ./dosbox
./dosbox -conf ./dosbox-SVN.conf
